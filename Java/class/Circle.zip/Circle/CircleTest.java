public class CircleTest {
    public static void main(String[] args) {
        Circle c1 = new Circle();

        System.out.println("The radius is " + c1.getRadius());
        System.out.println("The area is " + c1.getArea());
    }
}
